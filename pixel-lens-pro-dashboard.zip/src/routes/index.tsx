import { createFileRoute } from "@tanstack/react-router";
import { TopNav } from "@/components/dashboard/TopNav";
import { PageHeader } from "@/components/dashboard/PageHeader";
import { StatsStrip } from "@/components/dashboard/StatsStrip";
import { FilterBar } from "@/components/dashboard/FilterBar";
import { ProjectCard, type Project } from "@/components/dashboard/ProjectCard";
import { RecentActivity } from "@/components/dashboard/RecentActivity";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pixel Lens Pro — Design QA Dashboard" },
      {
        name: "description",
        content:
          "Track design accuracy across your builds. Pixel Lens Pro auto-captures pages from your browser extension and surfaces every issue here.",
      },
      { property: "og:title", content: "Pixel Lens Pro — Design QA Dashboard" },
      {
        property: "og:description",
        content:
          "AI-powered UI/UX QA. See every scan from the PixelLens Pro extension in one place.",
      },
    ],
  }),
  component: Index,
});

const projects: Project[] = [
  {
    name: "E-commerce Website",
    domain: "shop.acme.com",
    status: "issues",
    totalIssues: 42,
    highSeverity: 6,
    lastScan: "2 hours ago",
    preview: "ecom",
  },
  {
    name: "Acme SaaS Dashboard",
    domain: "app.acme.io",
    status: "review",
    totalIssues: 18,
    highSeverity: 1,
    lastScan: "5 hours ago",
    preview: "saas",
  },
  {
    name: "Marketing Site",
    domain: "acme.com",
    status: "good",
    totalIssues: 3,
    highSeverity: 0,
    lastScan: "1 day ago",
    preview: "marketing",
  },
  {
    name: "Checkout Flow",
    domain: "pay.acme.com",
    status: "issues",
    totalIssues: 27,
    highSeverity: 2,
    lastScan: "30 minutes ago",
    preview: "checkout",
  },
  {
    name: "Editorial Blog",
    domain: "blog.acme.com",
    status: "review",
    totalIssues: 11,
    highSeverity: 0,
    lastScan: "3 days ago",
    preview: "blog",
  },
  {
    name: "Portfolio v2",
    domain: "studio.acme.dev",
    status: "good",
    totalIssues: 0,
    highSeverity: 0,
    lastScan: "6 hours ago",
    preview: "portfolio",
  },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <TopNav />

      <main className="mx-auto max-w-7xl px-6 py-8 lg:py-10">
        <div className="space-y-8 animate-fade-up">
          <PageHeader />
          <StatsStrip />

          <section className="space-y-4">
            <FilterBar />
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {projects.map((p) => (
                <ProjectCard key={p.name} project={p} />
              ))}
            </div>
          </section>

          <RecentActivity />

          <footer className="flex items-center justify-between border-t border-border pt-6 text-xs text-muted-foreground">
            <span>© Pixel Lens Pro</span>
            <span className="font-mono">v1.4.2 · synced just now</span>
          </footer>
        </div>
      </main>
    </div>
  );
}
